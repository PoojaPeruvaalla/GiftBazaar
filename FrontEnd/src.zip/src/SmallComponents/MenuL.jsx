import React from 'react'
import CloseIcon from '@mui/icons-material/Close';
const MenuL = () => {
  return (
    <>
      <div style={{border:"2px solid red",width:"300px",height:"900px"}}>
        <CloseIcon ></CloseIcon>
        <aside style={{ margin:"auto",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",border:"2px solid green"}}>
              <ul className='flex justify-center items-center flex-col gap-4'>
                <li className='text-red-500 '>Home</li>
                <li className='text-red-500 '>Shop</li>
                <li className='text-red-500 '>About</li>
                <li className='text-red-500 '>Contact</li>
              </ul>
        </aside>
        
      </div>
    </>
  )
}

export default MenuL