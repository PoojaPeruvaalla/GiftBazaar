import { useMemo, useState } from 'react';
import NavBar from './NavBar';
import { Outlet } from 'react-router';
import Layout from './Layout';
import './Shop.css'

const Shop = () => {
  const gift = [
    {
      id: 1,
      name: "Personalized Photo Frame",
      category: "Personalized",
      occasion: ["Birthday", "Anniversary", "Wedding"],
      recipient: ["Couples", "Friends", "Parents"],
      price: 599,
      originalPrice: 899,
      rating: 4.5,
      stock: 20,
      image: "/images/photo-frame.jpg",
      description: "A beautiful customized photo frame for memorable moments."
    },
    {
      id: 2,
      name: "Red Rose Bouquet",
      category: "Flowers",
      occasion: ["Anniversary", "Valentine's Day", "Birthday"],
      recipient: ["Women", "Couples"],
      price: 799,
      originalPrice: 1099,
      rating: 4.7,
      stock: 15,
      image: "/images/rose-bouquet.jpg",
      description: "Fresh red roses arranged beautifully for special occasions."
    },
    {
      id: 3,
      name: "Premium Chocolate Gift Box",
      category: "Chocolates",
      occasion: ["Birthday", "Valentine's Day", "Festival"],
      recipient: ["Friends", "Couples", "Kids"],
      price: 499,
      originalPrice: 699,
      rating: 4.6,
      stock: 30,
      image: "/images/chocolate-box.jpg",
      description: "A delicious assortment of premium chocolates."
    },
    {
      id: 4,
      name: "Personalized Coffee Mug",
      category: "Personalized",
      occasion: ["Birthday", "Anniversary", "Graduation"],
      recipient: ["Friends", "Men", "Women"],
      price: 349,
      originalPrice: 499,
      rating: 4.3,
      stock: 40,
      image: "/images/custom-mug.jpg",
      description: "Customize this mug with your favorite photo or message."
    },
    {
      id: 5,
      name: "Luxury Wrist Watch",
      category: "Accessories",
      occasion: ["Birthday", "Anniversary", "Graduation"],
      recipient: ["Men", "Women"],
      price: 2499,
      originalPrice: 3499,
      rating: 4.8,
      stock: 10,
      image: "/images/wrist-watch.jpg",
      description: "Elegant wristwatch suitable for special occasions."
    },
    {
      id: 6,
      name: "Cute Teddy Bear",
      category: "Toys",
      occasion: ["Birthday", "Valentine's Day"],
      recipient: ["Kids", "Women", "Couples"],
      price: 699,
      originalPrice: 999,
      rating: 4.5,
      stock: 25,
      image: "/images/teddy-bear.jpg",
      description: "Soft and adorable teddy bear for your loved ones."
    },
    {
      id: 7,
      name: "Personalized Name Necklace",
      category: "Accessories",
      occasion: ["Birthday", "Anniversary", "Valentine's Day"],
      recipient: ["Women", "Couples"],
      price: 999,
      originalPrice: 1499,
      rating: 4.7,
      stock: 18,
      image: "/images/name-necklace.jpg",
      description: "Beautiful personalized necklace with a custom name."
    },
    {
      id: 8,
      name: "LED Photo Lamp",
      category: "Home Decor",
      occasion: ["Birthday", "Anniversary", "Wedding"],
      recipient: ["Couples", "Friends", "Parents"],
      price: 899,
      originalPrice: 1299,
      rating: 4.6,
      stock: 12,
      image: "/images/photo-lamp.jpg",
      description: "A glowing LED lamp customized with memorable photos."
    },
    {
      id: 9,
      name: "Birthday Gift Hamper",
      category: "Gift Hampers",
      occasion: ["Birthday"],
      recipient: ["Friends", "Men", "Women"],
      price: 1499,
      originalPrice: 1999,
      rating: 4.8,
      stock: 20,
      image: "/images/birthday-hamper.jpg",
      description: "A special hamper filled with birthday surprises."
    },
    {
      id: 10,
      name: "Scented Candle Set",
      category: "Home Decor",
      occasion: ["Birthday", "Wedding", "Festival"],
      recipient: ["Women", "Friends", "Parents"],
      price: 649,
      originalPrice: 899,
      rating: 4.4,
      stock: 35,
      image: "/images/candle-set.jpg",
      description: "Aromatic candles perfect for relaxation and decoration."
    },
    {
      id: 11,
      name: "Customized Keychain",
      category: "Personalized",
      occasion: ["Birthday", "Anniversary", "Graduation"],
      recipient: ["Friends", "Men", "Women"],
      price: 199,
      originalPrice: 299,
      rating: 4.2,
      stock: 50,
      image: "/images/keychain.jpg",
      description: "Personalized keychain with name or photo."
    },
    {
      id: 12,
      name: "Designer Handbag",
      category: "Accessories",
      occasion: ["Birthday", "Anniversary", "Festival"],
      recipient: ["Women"],
      price: 1999,
      originalPrice: 2799,
      rating: 4.6,
      stock: 14,
      image: "/images/handbag.jpg",
      description: "Stylish handbag for everyday use and special occasions."
    },
    {
      id: 13,
      name: "Bluetooth Speaker",
      category: "Electronics",
      occasion: ["Birthday", "Graduation", "Festival"],
      recipient: ["Men", "Women", "Friends"],
      price: 1799,
      originalPrice: 2499,
      rating: 4.7,
      stock: 16,
      image: "/images/bluetooth-speaker.jpg",
      description: "Portable Bluetooth speaker with excellent sound quality."
    },
    {
      id: 14,
      name: "Couple Photo Album",
      category: "Personalized",
      occasion: ["Anniversary", "Wedding", "Valentine's Day"],
      recipient: ["Couples"],
      price: 1199,
      originalPrice: 1599,
      rating: 4.8,
      stock: 10,
      image: "/images/photo-album.jpg",
      description: "Customized album to preserve beautiful memories."
    },
    {
      id: 15,
      name: "Indoor Plant Gift",
      category: "Plants",
      occasion: ["Birthday", "Festival", "Wedding"],
      recipient: ["Friends", "Parents", "Women"],
      price: 449,
      originalPrice: 649,
      rating: 4.5,
      stock: 28,
      image: "/images/indoor-plant.jpg",
      description: "A beautiful indoor plant for home decoration."
    },
    {
      id: 16,
      name: "Kids Building Blocks",
      category: "Toys",
      occasion: ["Birthday", "Festival"],
      recipient: ["Kids"],
      price: 899,
      originalPrice: 1199,
      rating: 4.6,
      stock: 22,
      image: "/images/building-blocks.jpg",
      description: "Creative building blocks that encourage learning and imagination."
    },
    {
      id: 17,
      name: "Premium Perfume Set",
      category: "Accessories",
      occasion: ["Birthday", "Anniversary", "Valentine's Day"],
      recipient: ["Men", "Women"],
      price: 1599,
      originalPrice: 2199,
      rating: 4.7,
      stock: 18,
      image: "/images/perfume-set.jpg",
      description: "Luxury perfume collection with refreshing fragrances."
    },
    {
      id: 18,
      name: "Wedding Gift Hamper",
      category: "Gift Hampers",
      occasion: ["Wedding", "Anniversary"],
      recipient: ["Couples"],
      price: 2999,
      originalPrice: 3999,
      rating: 4.9,
      stock: 8,
      image: "/images/wedding-hamper.jpg",
      description: "Elegant wedding hamper filled with premium gifts."
    },
    {
      id: 19,
      name: "Personalized Cushion",
      category: "Personalized",
      occasion: ["Birthday", "Anniversary", "Valentine's Day"],
      recipient: ["Couples", "Friends", "Parents"],
      price: 549,
      originalPrice: 799,
      rating: 4.4,
      stock: 30,
      image: "/images/custom-cushion.jpg",
      description: "Soft cushion customized with photos or messages."
    },
    {
      id: 20,
      name: "Decorative Wall Clock",
      category: "Home Decor",
      occasion: ["Wedding", "Festival", "Anniversary"],
      recipient: ["Parents", "Couples"],
      price: 1299,
      originalPrice: 1799,
      rating: 4.5,
      stock: 17,
      image: "/images/wall-clock.jpg",
      description: "Modern decorative wall clock for beautiful interiors."
    },
    {
      id: 21,
      name: "Graduation Gift Box",
      category: "Gift Hampers",
      occasion: ["Graduation"],
      recipient: ["Friends", "Men", "Women"],
      price: 999,
      originalPrice: 1399,
      rating: 4.6,
      stock: 20,
      image: "/images/graduation-box.jpg",
      description: "Special graduation gift box to celebrate achievements."
    },
    {
      id: 22,
      name: "Artificial Flower Vase",
      category: "Home Decor",
      occasion: ["Wedding", "Anniversary", "Festival"],
      recipient: ["Women", "Parents", "Couples"],
      price: 749,
      originalPrice: 999,
      rating: 4.3,
      stock: 25,
      image: "/images/flower-vase.jpg",
      description: "Elegant artificial flower arrangement with a decorative vase."
    },
    {
      id: 23,
      name: "Kids Remote Control Car",
      category: "Toys",
      occasion: ["Birthday", "Festival"],
      recipient: ["Kids"],
      price: 1299,
      originalPrice: 1799,
      rating: 4.7,
      stock: 15,
      image: "/images/remote-car.jpg",
      description: "Fun remote-controlled car for children."
    },
    {
      id: 24,
      name: "Dry Fruits Gift Box",
      category: "Gift Hampers",
      occasion: ["Festival", "Wedding"],
      recipient: ["Parents", "Friends", "Couples"],
      price: 1399,
      originalPrice: 1899,
      rating: 4.6,
      stock: 22,
      image: "/images/dry-fruits.jpg",
      description: "Premium dry fruits beautifully packed for gifting."
    },
    {
      id: 25,
      name: "Personalized Diary",
      category: "Personalized",
      occasion: ["Birthday", "Graduation", "Festival"],
      recipient: ["Friends", "Men", "Women"],
      price: 399,
      originalPrice: 599,
      rating: 4.4,
      stock: 35,
      image: "/images/custom-diary.jpg",
      description: "Personalized diary with custom name engraving."
    }
  ];

  const categories = [
    "All",
    ...new Set(gift.map((item) => item.category))
  ];

  // occasion and recipient are arrays, so use flatMap()
  const occasions = [
    "All",
    ...new Set(gift.flatMap((item) => item.occasion))
  ];

  const recp1 = [
    "All",
    ...new Set(gift.flatMap((item) => item.recipient))
  ];

  const [category, setCategory] = useState("All");
  const [occasion, setOccasion] = useState("All");
  const [recp, setRecp] = useState("All");
  const [search, setSearch] = useState("");

  const filteredGifts = useMemo(() => {
    return gift.filter((item) => {
      const itemCategory = item.category.toLowerCase();
      const itemName = item.name.toLowerCase();

      const selectedCategory = category.toLowerCase();
      const selectedOccasion = occasion.toLowerCase();
      const selectedRecp = recp.toLowerCase();
      const searchTerm = search.toLowerCase().trim();

      // Category filter
      if (
        selectedCategory !== "all" &&
        itemCategory !== selectedCategory
      ) {
        return false;
      }

      // Occasion filter: item.occasion is an array
      if (
        selectedOccasion !== "all" &&
        !item.occasion.some(
          (oc) => oc.toLowerCase() === selectedOccasion
        )
      ) {
        return false;
      }

      // Recipient filter: item.recipient is an array
      if (
        selectedRecp !== "all" &&
        !item.recipient.some(
          (recipient) => recipient.toLowerCase() === selectedRecp
        )
      ) {
        return false;
      }

      // Search filter
      if (searchTerm && !itemName.includes(searchTerm)) {
        return false;
      }

      return true;
    });
  }, [category, occasion, recp, search]);

  return (
    <>
      <Layout></Layout>
<article className='flex border border-black justify-around'>
  
      <aside className="flex gap-4 flex-wrap border justify-around items-center">
        {/* Category filters */}
        <div className="flex flex-row gap-3">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`text-left text-xl ${
                category === cat ? "font-bold" : "text-gray-900"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
         <div>
          <input
            type="text"
            placeholder="Search gifts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="form-control border border-black"
          />
        </div>
      
</aside>
</article>
<aside className='flex  flex-around border border-black justify-center min-h-screen ' >
        <section className='flex flex-col border items-start  '>
          <div className="flex flex-col gap-3 w-[200px]">
          <h3>Occasions</h3>

          {occasions.map((cat) => (
            <button
              key={cat}
              onClick={() => setOccasion(cat)}
              className={`text-left text-xl ${
                occasion === cat ? "font-bold" : "text-gray-900"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Recipient filters */}
        <div className="flex flex-col gap-3">
          <h3>Recipients</h3>

          {recp1.map((cat) => (
            <button
              key={cat}
              onClick={() => setRecp(cat)}
              className={`text-left text-xl ${
                recp === cat ? "font-bold" : "text-gray-900"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        </section>
            {/* products list */}
        <section className=' border w-[900px] border-black'>
           <ul className=''>
        {filteredGifts.length === 0 ? (
          <p
            style={{
              marginTop: "20px",
              fontWeight: "bold",
              color: "red"
            }}
          >
            No items found
          </p>
        ) : (
          filteredGifts.map((item) => (
            <div key={item.id} className='grid grid-row-3 w-[200px] h-30 border gap-40' id='card'>
              
              <aside>{item.name} — ₹{item.price}</aside>
            </div>
          ))
        )}
      </ul>
        </section>
</aside>
     
    </>
  );
};

export default Shop;