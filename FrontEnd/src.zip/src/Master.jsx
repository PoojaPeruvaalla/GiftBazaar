// import React from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router'
import Home from './Home'
// import App from './App'
import Login from './Login'
import Register from './Register'
import Shop from './Shop'
import Cart from './Cart'
import Like from './Like'
let Router=createBrowserRouter(
  [
    {
      path:"/",
      element:<Home></Home>
    },
    {
      path:"/login",
      element:<Login></Login>
    },
    {
      path:"/register",
      element:<Register></Register>
    },{
      path:"/shop",
      element:<Shop></Shop>
    },
    {
      path:"/cart",
      element:<Cart/>
    },
    {
      path:"/like",
      element:<Like/>
    }
  ]
)
const Master = () => {
  return (
    <>
    <RouterProvider router={Router}></RouterProvider>
    
    </>
  )
}

export default Master