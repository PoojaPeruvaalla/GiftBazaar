// import React from 'react'
// import { Link } from 'react-router'
import './index.css'
import Layout from './Layout'
import NavBar from './NavBar'
import Carousals from './SmallComponents/Carousals'
// import Carousels from './SmallComponents/Carousals'
// import NavBar from "./NavBar"

const Home = () => {
  return (
   <>
   <Layout></Layout>
    <Carousals/>
   </>
  )
}

export default Home