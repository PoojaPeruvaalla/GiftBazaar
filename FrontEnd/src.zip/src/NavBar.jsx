// import React from 'react'
import './index.css'
import DehazeIcon from '@mui/icons-material/Dehaze';
import FavoriteIcon from '@mui/icons-material/Favorite';
import StorefrontIcon from '@mui/icons-material/Storefront';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import CloseIcon from '@mui/icons-material/Close';
import { useState } from 'react';
import { Link} from 'react-router';
// import { Link } from "react-router"
// import styled from "styled-components"

const NavBar = () => {
    let [display,setDissplay]=useState(false)
    let dis=()=>{
        setDissplay(true)
    }
   
  return (
   <>
    <nav className="flex justify-around w-100  items-center  h-20">
        <div className='flex gap-3 '>
           <button onClick={dis}><DehazeIcon/></button>
            <h4 className="text-black">GIFTBAZAAR</h4>
        </div>
        <div className='flex gap-3'>
            <div className="flex gap-3">
  <Link to="/shop">
    <StorefrontIcon className="text-black" />
  </Link>

  <Link to="/login">
    <FavoriteIcon className="text-black" />
  </Link>

  <Link to="/login">
    <ShoppingCartIcon className="text-black" />
  </Link>

  <Link to="/login">
    <AccountCircleIcon className="text-black" />
  </Link>
</div>

            
        </div>
    </nav>
    {display &&
    <>
     <div onClick={()=>setDissplay(false)} style={{ position: "fixed",inset: 0,width: "100%",height: "100vh",background: "rgba(0,0,0,0.4)",zIndex: 9999}}>
        <aside style={{ margin:"auto",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",position:'fixed', top:0, left:0, width:'300px', background:'white', padding:'20px',zIndex:1000,flexDirection:"column",boxShadow:"5px 5px 5px grey"}}>
        <CloseIcon onClick={()=>setDissplay(false)} style={{cursor:"pointer",position:"absolute",top:10,right:8}} ></CloseIcon>
              <ul className='flex justify-center items-center flex-col gap-4'>
                <Link to="/">Home</Link>
                <Link to="/shop" className='link-tag cursor-pointer'>Shop</Link>
                <li className='text-red-500 no-underline hover:underline cursor-pointer'>About</li>
                <li className='text-red-500 no-underline hover:underline cursor-pointer'>Contact</li>
              </ul>
        </aside>
        
      </div>
    </>}
   </>
  )
}

export default NavBar